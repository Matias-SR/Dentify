package com.dentify.dentista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
